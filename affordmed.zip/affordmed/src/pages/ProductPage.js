// src/pages/ProductPage.js
import React from 'react';
import { useParams } from 'react-router-dom';
import ProductDetail from '../components/ProductDetail';

const ProductPage = () => {
  const { id } = useParams();
  return <ProductDetail productId={id} />;
};

export default ProductPage;
