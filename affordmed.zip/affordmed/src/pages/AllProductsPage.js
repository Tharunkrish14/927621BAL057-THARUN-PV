// src/pages/AllProductsPage.js
import React from 'react';
import { Container, Typography } from '@mui/material';
import ProductList from '../components/ProductList';
import Filters from '../components/Filters';

const AllProductsPage = () => {
  return (
    <Container>
      <Typography variant="h2" gutterBottom>
        Top Products
      </Typography>
      <Filters />
      <ProductList />
    </Container>
  );
};

export default AllProductsPage;
