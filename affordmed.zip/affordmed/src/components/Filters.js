// src/components/Filters.js
import React, { useState } from 'react';
import { Box, TextField, Button } from '@mui/material';

const Filters = ({ setFilters }) => {
  const [category, setCategory] = useState('');
  const [company, setCompany] = useState('');

  const applyFilters = () => {
    setFilters({ category, company });
  };

  return (
    <Box mb={3} display="flex" justifyContent="space-between">
      <TextField
        label="Category"
        variant="outlined"
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      />
      <TextField
        label="Company"
        variant="outlined"
        value={company}
        onChange={(e) => setCompany(e.target.value)}
      />
      <Button variant="contained" color="primary" onClick={applyFilters}>
        Apply Filters
      </Button>
    </Box>
  );
};

export default Filters;
