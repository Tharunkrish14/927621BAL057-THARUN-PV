// src/components/ProductDetail.js
import React, { useEffect, useState } from 'react';
import { Container, Typography, Card, CardContent, CardMedia } from '@mui/material';
import { fetchProductById } from '../api';

const ProductDetail = ({ productId }) => {
  const [product, setProduct] = useState(null);

  useEffect(() => {
    const getProduct = async () => {
      const data = await fetchProductById(productId);
      setProduct(data);
    };
    getProduct();
  }, [productId]);

  if (!product) return null;

  return (
    <Container>
      <Card>
        <CardMedia
          component="img"
          alt={product.name}
          height="300"
          image={`https://via.placeholder.com/300?text=${product.name}`}
        />
        <CardContent>
          <Typography variant="h3">{product.name}</Typography>
          <Typography variant="h5">{product.company}</Typography>
          <Typography variant="body1">{product.category}</Typography>
          <Typography variant="body2">Price: {product.price}</Typography>
          <Typography variant="body2">Rating: {product.rating}</Typography>
          <Typography variant="body2">Discount: {product.discount}</Typography>
          <Typography variant="body2">Availability: {product.availability}</Typography>
        </CardContent>
      </Card>
    </Container>
  );
};

export default ProductDetail;
