// src/components/ProductList.js
import React, { useEffect, useState } from 'react';
import { Grid, Card, CardContent, CardMedia, Typography } from '@mui/material';
import { fetchProducts } from '../api';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const getProducts = async () => {
      const data = await fetchProducts();
      setProducts(data);
    };
    getProducts();
  }, []);

  return (
    <Grid container spacing={3}>
      {products.map((product) => (
        <Grid item xs={12} sm={6} md={4} key={product.id}>
          <Card>
            <CardMedia
              component="img"
              alt={product.name}
              height="140"
              image={`https://via.placeholder.com/150?text=${product.name}`}
            />
            <CardContent>
              <Typography variant="h5">{product.name}</Typography>
              <Typography variant="subtitle1">{product.company}</Typography>
              <Typography variant="body2">{product.category}</Typography>
              <Typography variant="body2">Price: {product.price}</Typography>
              <Typography variant="body2">Rating: {product.rating}</Typography>
              <Typography variant="body2">Discount: {product.discount}</Typography>
              <Typography variant="body2">Availability: {product.availability}</Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default ProductList;
